<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class WebhooksController extends Controller
{
    function handle(Request $request)
    {
        $payload = $request->all();
        Log::info("message received: " . json_encode($payload));
        // Do something with the payload
        return response()->json(['status' => 'success']);
    }
}
